package com.boycandra.login

class User(
    var id: String,
    var userName: String,
    var email: String,
    var password: String
)