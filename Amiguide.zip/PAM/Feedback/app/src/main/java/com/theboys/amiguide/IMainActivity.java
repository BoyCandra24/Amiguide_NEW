package com.theboys.amiguide;

import com.theboys.amiguide.models.Note;

public interface IMainActivity {

    void createNewNote(String title, String content);

    void updateNote(Note note);

    void onNoteSelected(Note note);

    void deleteNote(Note note);
}