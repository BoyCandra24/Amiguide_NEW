package com.theboys.amiguide;

import android.app.Activity;

public class SignUpActivity extends Activity {
}
